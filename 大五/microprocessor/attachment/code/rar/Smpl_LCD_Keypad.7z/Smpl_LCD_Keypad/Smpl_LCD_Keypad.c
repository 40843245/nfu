//
// Sample Code : Smpl_7seg_Keypad                                                                          
//
//      input  : 3x3 Keypad
//      output : 7-segment display
//
#include <stdio.h>																	 
#include "NUC1xx.h"
#include "Seven_Segment.h"
#include "scankey.h"
#define BAUDRATE 9600

void Delay(int32_t count)
{
	while(count--)
	{
//		__NOP;
	 }
}

/*----------------------------------------------------------------------------
  MAIN function
  ----------------------------------------------------------------------------*/
int32_t main (void)
{
	int8_t number;
	char text[15]="Key =   ";
	
	UNLOCKREG();
	SYSCLK->PWRCON.XTL12M_EN = 1; 	//Enable 12Mhz and set HCLK->12Mhz
	SYSCLK->CLKSEL0.HCLK_S = 0;
	LOCKREG();

	Initial_pannel();
	clr_all_pannal();

	OpenKeyPad();					 	
	 
	while(1)
	{
	    number = Scankey(); 
		close_seven_segment();
		show_seven_segment(0,number);


		sprintf(text+8,"%d",number);			  
		print_lcd(0, text);	  

		Delay(5000); 																			 
	}

}

